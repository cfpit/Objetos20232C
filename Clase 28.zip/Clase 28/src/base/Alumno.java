package base;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.util.ArrayList;
//import java.sql.*;

public class Alumno {
    private String nombre;
    private int edad;

    public Alumno() {}

    public Alumno(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return nombre + " - " + edad;
    }
    
    //metodos de acceso a datos ABMC (CRUD)
    public static void consultarTodos() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la query
        String unaConsulta = "select * from alumnos";
        
        //creo una sentencia que ejecutara la query
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        //recorro el resultado y muestro en consola
        while (unResultado.next()) {            
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("-----------------------------------");
        }
        
        //cierro la conexion
        unaConexion.close();
        
    }
    
    
    public static void consultarUno(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la query
        String unaConsulta = "select * from alumnos where nombre = '" + nombre + "'";
        
        //creo una sentencia que ejecutara la query
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        //recorro el resultado y muestro en consola
        if (unResultado.next()) {            
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("-----------------------------------");
        }
        
        //cierro la conexion
        unaConexion.close();
        
    }
    
    
    public static void insertar(Alumno a) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia
        String unaInsercion = "insert into alumnos(nombre, edad) values(?, ?)";
        
        //creo una sentencia que ejecutara la insercion
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaInsercion);
        
        //configuro los parametros de la sentencia
        unaSentencia.setString(1, a.getNombre());
        unaSentencia.setInt(2, a.getEdad());
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        System.out.println("Insercion correcta");
        
        //cierro la conexion
        unaConexion.close();
        
    }
    
    
    public static void eliminar(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia
        String unaEliminacion = "delete from alumnos where nombre = ?";
        
        //creo una sentencia que ejecutara la eliminacion
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaEliminacion);
        
        //configuro los parametros de la sentencia
        unaSentencia.setString(1, nombre);
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        System.out.println("Eliminacion correcta");
        
        //cierro la conexion
        unaConexion.close();
        
    }
    
    
    public static void actualizar(String nombreAnterior, String nombreNuevo) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la sentencia
        String unaActualizacion = "update alumnos set nombre = ? where nombre = ?";
        
        //creo una sentencia que ejecutara la actualizacion
        PreparedStatement unaSentencia = unaConexion.prepareStatement(unaActualizacion);
        
        //configuro los parametros de la sentencia
        unaSentencia.setString(1, nombreNuevo);
        unaSentencia.setString(2, nombreAnterior);
        
        //ejecuto la sentencia
        unaSentencia.execute();
        
        System.out.println("Actualizacion correcta");
        
        //cierro la conexion
        unaConexion.close();
        
    }
    
    
    public static ArrayList cargarListado() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo la coleccion que guardara los objetos mapeados desde la BD
        ArrayList<Alumno> lista = new ArrayList<>();

        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la query
        String unaConsulta = "select * from alumnos";
        
        //creo una sentencia que ejecutara la query
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        //recorro el resultado y guardo en la coleccion
        while (unResultado.next()) {            
            String nombre = unResultado.getString("nombre");
            int edad = unResultado.getInt("edad");
            
            //armo el objeto
            Alumno a = new Alumno(nombre, edad);
            
            //guardo el objeto en la coleccion
            lista.add(a);
        }
        
        //cierro la conexion
        unaConexion.close();
        
        //retorno la coleccion
        return lista;
        
    }
}
