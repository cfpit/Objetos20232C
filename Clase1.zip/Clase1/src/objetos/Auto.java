package objetos;

public class Auto {
    //atributos
    public String marca;
    public String color;
    public int velocidad;
    
    //constructores
    //vacio o por defecto
    public Auto() {}
    
    //metodos
    public void acelerar() {
        velocidad += 10;//velocidad = velocidad + 10
    }
    
    public void frenar() {
        velocidad -= 5;//velocidad = velocidad - 5
    }

    @Override
    public String toString() {
        return "marca=" + marca + ", color=" + color + ", velocidad=" + velocidad;
    }
    
    public void informar() {
        System.out.println("marca = " + marca);
        System.out.println("color = " + color);
        System.out.println("velocidad = " + velocidad);
    }

}
