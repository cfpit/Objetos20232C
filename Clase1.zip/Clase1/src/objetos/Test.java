package objetos;

public class Test {
    public static void main(String[] args) {
        //creo un objeto de la clase Auto
        Auto a = new Auto();
        
        //le doy un estado inicial
        a.marca = "Ford";
        a.color = "Gris";
        a.velocidad = 0;
        
        //comportamiento
        a.acelerar();//0 -> 10
        a.acelerar();//10 -> 20
        a.acelerar();//20 -> 30
        a.frenar();//30 -> 25
        
        //muestro el estado del auto
//        a.informar();

        System.out.println(a.toString());

        
        
        
        
    }
}
