package base;

import java.sql.SQLException;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
//        System.out.println("Consultar Todos");
//        Alumno.consultarTodos();

//        System.out.println("Consultar Uno");
//        Alumno.consultarUno("Juan");
//        System.out.println("Insercion");
//        Scanner lector = new Scanner(System.in);
//        
//        System.out.println("Ingrese el nombre del alumno: ");
//        String nombre = lector.next();
//        
//        System.out.println("Ingrese la edad del alumno: ");
//        int edad = lector.nextInt();
//        
//        //armo el objeto con los datos introducidos x teclado
//        Alumno a = new Alumno(nombre, edad);
//        
//        //Invoco el metodo insertar pasandole como parametro
//        //el objeto de la clase Alumno q se insertara como registro
//        //en la tabla alumnos de la base de datos
//        Alumno.insertar(a);
//        
//        //verifico la insercion
//        Alumno.consultarTodos();



//        System.out.println("Eliminacion");
//
//        Scanner lector = new Scanner(System.in);
//
//        System.out.println("Ingrese el nombre del alumno a eliminar: ");
//        String nombre = lector.next();
//
//        //Invoco el metodo eliminar pasandole como parametro
//        //el nombre del alumno a eliminar
//        Alumno.eliminar(nombre);
//
//        //verifico la eliminacion
//        Alumno.consultarTodos();
        
        
        
        System.out.println("Actualizacion");

        Scanner lector = new Scanner(System.in);

        System.out.println("Ingrese el anterior nombre del alumno: ");
        String nombreAnterior = lector.next();
        
        System.out.println("Ingrese el nuevo nombre del alumno: ");
        String nombreNuevo = lector.next();

        //Invoco el metodo actualizar pasandole como parametros
        //el anterior y el nuevo nombre del alumno
        Alumno.actualizar(nombreAnterior, nombreNuevo);

        //verifico la actualizacion
        Alumno.consultarTodos();

    }
}



