package colecciones.generics;

import java.util.ArrayList;

public class Generica<T> {
    ArrayList<T> coleccion = new ArrayList<>();
    
    //metodos delegados
    public int tamaño() {
        return coleccion.size();
    }

    public T obtener(int index) {
        return coleccion.get(index);
    }

    public boolean agregar(T e) {
        return coleccion.add(e);
    }

    public T eliminar(int index) {
        return coleccion.remove(index);
    }

    public boolean eliminar(Object o) {
        return coleccion.remove(o);
    }
    
    
    
    public void listar() {
        System.out.println(coleccion);
    }
    
}
