package colecciones.generics;

public class Test {
    public static void main(String[] args) {
//        Generica<String> g = new Generica<>();
//        Generica<Integer> g = new Generica<>();
        Generica<Persona> g = new Generica<>();

//        g.agregar("Juan");
//        g.agregar("Maria");
//        g.agregar("Luis");
//        g.agregar("Carlos");
//        
//        g.listar();
//        g.eliminar("Luis");
//        g.listar();
        



//        g.agregar(25);
//        g.agregar(30);
//        g.agregar(40);
//        g.agregar(18);
//        
//        g.listar();
//        g.eliminar(25);
//        g.listar();
        


        
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Maria", 30);
        Persona p3 = new Persona("Luis", 20);
        Persona p4 = new Persona("Carlos", 40);

        g.agregar(p1);
        g.agregar(p2);
        g.agregar(p3);
        g.agregar(p4);
        
        for (int i = 0; i < g.tamaño(); i++) {
            System.out.println(g.obtener(i));
        }
        
        g.eliminar(p3);//eliminamos a Luis
        
        g.listar();
    }
}
