package relaciones1aN;

public class Test {
    public static void main(String[] args) {
        Concesionaria c = new Concesionaria("Autolatina SRL");
        
        Auto a1 = new Auto("Ford", "gris");
        Auto a2 = new Auto("Chevrolet", "azul");
        Auto a3 = new Auto("Fiat", "blanco");
        Auto a4 = new Auto("Renault", "bordo");
        
        c.agregar(a1);
        c.agregar(a2);
        c.agregar(a3);
        c.agregar(a4);
        
        System.out.println(c);
        
        
    }
}
