package relaciones1a1;

public class Motor {
    
    private int cilindrada;

    public Motor() {}

    public Motor(int cilindrada) {
        this.setCilindrada(cilindrada);
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return "cilindrada=" + cilindrada;
    }
}
