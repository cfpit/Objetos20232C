package abstractas;

public class Test {
    public static void main(String[] args) {
        //creo 3 objetos
        //no se puede crear un objeto de la clase Vehiculo x ser abstracta
//        Vehiculo v = new Vehiculo("blanco", 0);
        Avion a = new Avion("Fly Bondi", "amarillo", 0);
        Bici b = new Bici(28, "rojo", 0);
        
        //comportamiento
        a.acelerar();
        b.acelerar();
        
        
        //muestro el estado final
//        System.out.println(v);
//        System.out.println("--------------");
        
        System.out.println(a);
        System.out.println("--------------");
        
        System.out.println(b);
        System.out.println("--------------");
    }
}
