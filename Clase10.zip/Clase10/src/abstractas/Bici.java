package abstractas;

public class Bici extends Vehiculo{
    //atributos
    private int rodado;
    
    //constructores
    public Bici() {}

    public Bici(int rodado, String color, int velocidad) {
        super(color, velocidad);
        this.setRodado(rodado);
    }

    //getters y setters
    public int getRodado() {
        return rodado;
    }

    public void setRodado(int rodado) {
        this.rodado = rodado;
    }

    //metodos
    @Override
    public String toString() {
        return super.toString() + " rodado=" + rodado;
    }
    
    //implemento el metodo abstracto acelerar del padre
    @Override
    public void acelerar() {
        this.velocidad += 5;
    }
    
}









