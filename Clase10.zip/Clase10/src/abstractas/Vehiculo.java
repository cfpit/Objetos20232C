package abstractas;

public abstract class Vehiculo {
    //atributos
    private String color;
    protected int velocidad;
    
    //constructores
    public Vehiculo() {}

    public Vehiculo(String color, int velocidad) {
        this.setColor(color);
        this.setVelocidad(velocidad);
    }
    
    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    //metodos
    @Override
    public String toString() {
        return "color=" + color + ", velocidad=" + velocidad;
    }
    
    //creo el metodo abstracto acelerar.
    //Las clases hijas de Vehiculo(Avion y Bici)
    //DEBEN implementar el cuerpo de este metodo
    
    //La clase padre abstracta indica QUE comportamiento tendran las clases 
    //hijas pero no el COMO lo van a implementar
    //La clase hija Bici implementa el metodo acelerar subiendo de a 5km./h
    //La clase hija Avion implementa el metodo acelerar subiendo de a 300km./h
    
    public abstract void acelerar();
}








