package streams.lector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        //FileReader: lee de a caracteres el archivo y se lo pasa al
        //BufferedReader.
        
        //BufferedReader: almacena de a lineas enteras.

        //creo un objeto File q guardara la ruta del archivo
//        File archivo = new File("src\\streams\\lector\\archivo.txt");
        BufferedReader lector = null;
        try {
            File archivo = new File("src/streams/lector/archivo.txt");

            //creo el stream de lectura q lee el archivo de texto
            lector = new BufferedReader(new FileReader(archivo));

            //algoritmo de lectura
            String lineaLeida = "";
            boolean eof = false;//eof-> fin de archivo

            //mientras no se termine el archivo...
            while (!eof) {
                //...leo la linea entera devuelta por el stream
                lineaLeida = lector.readLine();

                //Si queda linea por leer...
                if (lineaLeida != null) {
                    //... la muestro en consola
                    System.out.println(lineaLeida);
                } else {
                    //...sino, cambio el flag para salir del bucle
                    eof = true;
                }
            }
            
            //cierro el stream por seguridad
            lector.close();
        
        } catch (FileNotFoundException e) {
            System.out.println("No se encuentra el archivo a leer");
        
        } catch (IOException e) {
            System.out.println("No se puede leer. Archivo corrupto");
        
        }  catch (Exception e) {
            System.out.println("Se produjo un error");
        }
        
        
    }
}













