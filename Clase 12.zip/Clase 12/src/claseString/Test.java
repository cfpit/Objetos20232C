package claseString;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        String frase = "Curso de Java";
        
        System.out.println("Longitud: " + frase.length());
        
        System.out.println("Primer caracter: " + frase.charAt(0));
        
        System.out.println("subString: " + frase.substring(0, 5));
        
        System.out.println("split: ") ;
                
        String [] array = new String[3];
        array = frase.split(" ");
        
        System.out.println(Arrays.toString(array));
        System.out.println(array[0]);//Curso
        
        System.out.println("tolowerCase: " + frase.toLowerCase());
        
        System.out.println("toUpperCase: " + frase.toUpperCase());
        
        System.out.println("replace: " + frase.replace('a', 'x'));
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}









