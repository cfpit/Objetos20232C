package palabraStatic;

import palabraFinal.*;

public class Test {
    public static void main(String[] args) {
        Auto a = new Auto("Ford", 0);
        
        //No se puede modificar una constante
//        a.VELMAX = 200;

        //defino el valor del atributo estatico o de clase
        Auto.velMin = 0;
        
        //muestro el valor de velocidad minima
        System.out.print("velocidad minima de todos los autos: ");
        System.out.println(Auto.velMin + "  Km./h.");
        
    }
}
