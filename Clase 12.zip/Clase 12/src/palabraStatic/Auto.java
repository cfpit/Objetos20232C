package palabraStatic;

//public final class Auto {


//public final class Auto {
public class Auto {
    //atributos
    private String marca;
    private int velocidad;
    public final int VELMAX = 180;//constante
    public static int velMin;//atributo de la Clase
    
    //constructores
    public Auto() {}

    public Auto(String marca, int velocidad) {
        this.setMarca(marca);
        this.setVelocidad(velocidad);
    }
    
    //getters y setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public final void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
    //metodos
    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + ", velocidad=" + velocidad + '}';
    }
    
}
