

package palabraFinal;


public class AutoCarrera extends Auto{

//el metodo no se puede sobreescribir
//    public final void setVelocidad(int velocidad) {
//        this.velocidad = velocidad;
//    }
}
