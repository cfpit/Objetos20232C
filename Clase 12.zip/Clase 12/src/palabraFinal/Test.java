package palabraFinal;

public class Test {
    public static void main(String[] args) {
        Auto a = new Auto("Ford", 0);
        
        //No se puede modificar una constante
//        a.VELMAX = 200;
    }
}
