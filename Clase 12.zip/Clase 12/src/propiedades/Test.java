package propiedades;

public class Test {
    public static void main(String[] args) {
        System.out.println("Propiedades del sistema: ");
        System.out.println(System.getProperties());
        
        System.out.println("-------------------------------------");
        
        System.out.println("Version de Java: ");
        System.out.println(System.getProperty("java.version"));
        
        System.out.println("-------------------------------------");
        
        System.out.print("Nombre del S.O.: ");
        System.out.println(System.getProperty("os.name"));
        
        //llamada al garbage collector
        System.gc();
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
