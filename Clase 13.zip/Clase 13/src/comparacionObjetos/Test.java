package comparacionObjetos;

public class Test {
    public static void main(String[] args) {
        Auto a1 = new Auto("Ford", 123);
        Auto a2 = new Auto("Ford", 123);
        
        //comparacion de referencias (con el ==)
        if (a1 == a2) 
        {
            System.out.println("tienen igual referencia");
        } 
        else 
        {
            System.out.println("tienen distinta referencia");
        }
        
        //comparacion de contenidos (con el equals)
        if (a1.equals(a2)) 
        {
            System.out.println("tienen igual contenido");
        } 
        else 
        {
            System.out.println("tienen distinto contenido");
        }
        
        System.out.println(a1.hashCode());
        System.out.println(a2.hashCode());
    }
}
