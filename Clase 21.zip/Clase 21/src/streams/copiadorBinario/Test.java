package streams.copiadorBinario;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try {
            File archivoOrigen = new File("src/streams/copiadorBinario/girasoles.jpg");
            File archivoDestino = new File("src/streams/copiadorBinario/copia.jpg");

            //creo los streams de lectura y escritura de datos binarios
            FileInputStream lector = new FileInputStream(archivoOrigen);
            FileOutputStream escritor = new FileOutputStream(archivoDestino);

            //bucle de copia
            int unByte;
            while ((unByte = lector.read()) != -1) {
                escritor.write(unByte);
            }

            //cierro los streams
            lector.close();
            escritor.close();
            
            System.out.println("Imagen copiada");
        } catch (FileNotFoundException e) {
            System.out.println("No se encuentra el archivo a copiar");
        
        } catch (IOException e) {
            System.out.println("No se puede copiar.");
        
        }  catch (Exception e) {
            System.out.println("Se produjo un error");
        }
    }
}
