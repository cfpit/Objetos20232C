package streams.escritor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        //si el archivo no existe --> lo crea y escribe dentro de el.
        //si el archivo existe --> lo sobrescribe o agrega con append.
        
        //creo un objeto File q tiene la ruta del archivo
        try {
            File archivo = new File("src/streams/escritor/archivo.txt");

            //creo el stream de escritura
            BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo));

            //genero el contenido a escribir dentro del archivo
            String linea1 = "Esta es la linea #1";
            String linea2 = "Esta es la linea #2";
            String linea3 = "Esta es la linea #3";

            //escribo mediante el stream en el archivo
            escritor.write(linea1);
            escritor.newLine();//salto de linea
            escritor.write(linea2, 0, linea2.length());
            escritor.newLine();
            escritor.write(linea3, 4, 6);
            escritor.newLine();

            //cierro el stream
            escritor.close();
            
            System.out.println("Archivo escrito");
        } catch (IOException e) {
            System.out.println("No se puede escribir en el archivo");
        } catch (Exception e) {
            System.out.println("Se produjo un error");
        }
    
    }
}
