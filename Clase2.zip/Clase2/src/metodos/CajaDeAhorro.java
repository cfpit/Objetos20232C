package metodos;

public class CajaDeAhorro {
    //atributos
    public int saldo;
    public String moneda;
    
    //constructor vacio
    public CajaDeAhorro() {}
    
    //metodos
    public void consultarSaldo() {
        System.out.println("saldo = " + saldo + " " + moneda);
    }
    
    public void depositar(int monto) {
        saldo += monto;
        int pirulo = 90;
    }
    
    public void sarasa(int monto) {
        System.out.println("monto = " + monto);
    }
    
    public String extraer(int monto) {
        if (monto > saldo) 
        {
            return "Fondos Insuficientes";
        } 
        else 
        {
            saldo -= monto;
            return "Extraccion OK!";
        }
    }
    
    
    
}
