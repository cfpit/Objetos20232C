package metodos;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        //creo dos cajas
        CajaDeAhorro cda = new CajaDeAhorro();
        CajaDeAhorro cda2 = new CajaDeAhorro();
        
        //le doy un estado a ambos objetos
        cda.moneda = "U$s";
        cda.saldo = 0;
        
        cda2.moneda = "$";
        cda2.saldo = 500;

        //comportamiento
        System.out.println("Ingrese el monto a depositar: ");
        int montoDeposito = lector.nextInt();//25000
        cda.depositar(montoDeposito);
        
        System.out.println("Ingrese el monto a extraer: ");
        int montoExtraccion = lector.nextInt();
        System.out.println(cda.extraer(montoExtraccion));
        
        
        cda.consultarSaldo();
        System.out.println("-----------------");
        cda2.consultarSaldo();
    
    }
}
