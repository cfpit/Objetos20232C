package sobrecarga;

public class Test {
    public static void main(String[] args) {
        //creo un auto
        Auto a = new Auto();
        
        //le doy un estado inicial al objeto
        a.marca = "Ford";
        a.velocidad = 0;
        
        //comportamiento
        a.acelerar();//0 -> 10
        a.acelerar(50);//10 -> 60
        a.acelerar(15, false);//60 -> 75
        a.acelerar(20, true);//75 -> 115
        a.frenar(70);//115 -> 45
        
        
        //muestro el estado final
        System.out.println(a);
    }
}





