package constructores;

public class Test {
    public static void main(String[] args) {
        Auto a = new Auto();
        Auto b = new Auto("Chevrolet", 20);
        Auto c = new Auto("Fiat", 45);
        
        //estado inicial del auto a
        a.marca = "Ford";
        a.velocidad = 15;
        
        //estado final
        System.out.println(a);
        System.out.println("----------------");
        System.out.println(b);
        System.out.println("----------------");
        System.out.println(c);
    }
}
