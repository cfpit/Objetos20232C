package constructores;

public class Auto {
    //atributos
    public String marca;
    public int velocidad;
    
    //constructor vacio
    public Auto() {}
    
    //constructor sobrecargado
    public Auto(String marca, int velocidad) {
        this.marca = marca;
        this.velocidad = velocidad;
    }
    
    //metodos
    //metodo acelerar sin sobrecarga
    public void acelerar() {
        this.velocidad += 10;
    }
    
    //metodo acelerar sobrecargado con 1 parametro
    public void acelerar(int km) {
        this.velocidad += km;
    }
    
    //metodo acelerar sobrecargado con 2 parametros
    public void acelerar(int km, boolean turbo) {
        if (turbo) {
            this.acelerar(km * 2);
        } else {
            this.acelerar(km);
        }
    }
    
    //metodo frenar sin sobrecarga
    public void frenar() {
        this.velocidad -= 5;
    }
    
    //metodo frenar sobrecargado con 1 parametro
    public void frenar(int km) {
        this.velocidad -= km;
    }

    @Override
    public String toString() {
        return "marca=" + marca + " - velocidad=" + velocidad;
    }
    
}
