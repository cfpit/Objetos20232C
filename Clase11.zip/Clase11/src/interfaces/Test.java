package interfaces;

public class Test {
    public static void main(String[] args) {
        //creo un gerente y un cadete
        Gerente g = new Gerente("Juan Perez", 250000, 10);
        Cadete c = new Cadete("Carlos Rios", 1000, 160);
        
        //comportamiento
        g.calcularSueldo();
        c.calcularSueldo();
    }
}
