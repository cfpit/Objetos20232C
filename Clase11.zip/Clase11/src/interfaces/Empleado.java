package interfaces;

public interface Empleado {
    //contrato
    public void calcularSueldo();
//    public void metodo1();
//    public void metodo2();
//    public void metodo3();
    
}
