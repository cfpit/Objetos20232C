

package encapsulamiento;


public class Test {
    public static void main(String[] args) {
        //creo un auto
        Auto a = new Auto();
        
        //defino el estado inicial del auto
        a.marca = "BMW";
//        a.setVelocidad(-500);
        a.setVelocidad(50);
//        a.setVelocidad(5000);

        //comportamiento
        a.acelerar(4500);
        
        //muestro el estado final
        System.out.println(a);
        
        
    }
}
