package excepciones.unchecked;

public class Test {
    public static void main(String[] args) {
        
        try {
            String palabra = "Hola";
            System.out.println("Longitud: " + palabra.length());
            
            String palabra2 = null;
//            System.out.println("Longitud: " + palabra2.length());

            Integer.parseInt("hola");

        } catch (NullPointerException e) {
            System.out.println("Error de puntero a nulo");
                
//                e.printStackTrace();
        } catch (NumberFormatException e) {
            System.out.println("Error de parseo");
        } catch (Exception e) {
            System.out.println("Error");
        }
        
        
        
        System.out.println("Sigue...");
    }
}
