package base;

import java.sql.SQLException;

public class Test {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
//        System.out.println("Consultar Todos");
//        Alumno.consultarTodos();
        
        System.out.println("Consultar Uno");
        Alumno.consultarUno("Juan");
    }
}













               