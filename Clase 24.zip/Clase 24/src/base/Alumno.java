package base;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
//import java.sql.*;

public class Alumno {
    private String nombre;
    private int edad;

    public Alumno() {}

    public Alumno(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
    
    //metodos de acceso a datos ABMC (CRUD)
    public static void consultarTodos() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la query
        String unaConsulta = "select * from alumnos";
        
        //creo una sentencia que ejecutara la query
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        //recorro el resultado y muestro en consola
        while (unResultado.next()) {            
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("-----------------------------------");
        }
        
        //cierro la conexion
        unaConexion.close();
        
    }
    
    
    public static void consultarUno(String nombre) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //creo una conexion
        Connection unaConexion = Conexion.obtenerConexion();
        
        //armo la query
        String unaConsulta = "select * from alumnos where nombre = '" + nombre + "'";
        
        //creo una sentencia que ejecutara la query
        Statement unaSentencia = unaConexion.createStatement();
        
        //ejecuto la query y guardo el resultado
        ResultSet unResultado = unaSentencia.executeQuery(unaConsulta);
        
        //recorro el resultado y muestro en consola
        if (unResultado.next()) {            
            System.out.println("Nombre: " + unResultado.getString("nombre"));
            System.out.println("Edad: " + unResultado.getInt("edad"));
            System.out.println("-----------------------------------");
        }
        
        //cierro la conexion
        unaConexion.close();
        
    }
    


}
