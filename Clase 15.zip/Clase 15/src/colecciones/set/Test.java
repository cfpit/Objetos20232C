package colecciones.set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class Test {
    public static void main(String[] args) {
////        HashSet<String> coleccion = new HashSet<>();//desordenado
////        LinkedHashSet<String> coleccion = new LinkedHashSet<>();//orden de ingreso
        TreeSet<String> coleccion = new TreeSet<>();//ordenado

        coleccion.add("Juan");
        coleccion.add("Maria");
        coleccion.add("Luis");
        coleccion.add("Carlos");
        
        System.out.println(coleccion);


//        HashSet<Integer> coleccion = new HashSet<>();//desordenado
////        LinkedHashSet<Integer> coleccion = new LinkedHashSet<>();//orden de ingreso
////        TreeSet<Integer> coleccion = new TreeSet<>();//ordenado
//
//        coleccion.add(25);
//        coleccion.add(40);
//        coleccion.add(35);
//        coleccion.add(20);
//        
//        
//        System.out.println(coleccion);


//        HashSet<Persona> coleccion = new HashSet<>();//desordenado
//        LinkedHashSet<Persona> coleccion = new LinkedHashSet<>();//orden de ingreso
//        TreeSet<Persona> coleccion = new TreeSet<>();//ordenado
//
//        coleccion.add(new Persona("Juan", 25));
//        coleccion.add(new Persona("Maria", 30));
//        coleccion.add(new Persona("Luis", 20));
//        coleccion.add(new Persona("Carlos", 40));
//        
//        System.out.println(coleccion);
    }
}
