package colecciones.mapas;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class Test {
    public static void main(String[] args) {
//        HashMap<String,String> mapa = new HashMap<>();
//        LinkedHashMap<String,String> mapa = new LinkedHashMap<>();
        TreeMap<String,String> mapa = new TreeMap<>();
        
        mapa.put("rojo", "red");
        mapa.put("verde", "green");
        mapa.put("azul", "blue");
        mapa.put("blanco", "white");
        mapa.put("negro", "black");
        mapa.put("naranja", "orange");
        
        System.out.println(mapa);
        
        //le pasas la clave y te devuelve el valor
        System.out.println(mapa.get("rojo"));
        System.out.println(mapa.getOrDefault("violeta", "sin traduccion"));
        
        //muestra solo las claves
        System.out.println(mapa.keySet());
        
        //muestra solo los valores
        System.out.println(mapa.values());
        
    }
}




