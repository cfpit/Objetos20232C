package polimorfismo;

public class AutoCarrera extends Auto{
    //atributos
    private String escuderia;
    
    //constructores
    public AutoCarrera() {}

    public AutoCarrera(String escuderia, String marca, int velocidad) {
        super(marca, velocidad);
        this.setEscuderia(escuderia);
    }

    //getters y setters
    public String getEscuderia() {
        return escuderia;
    }

    public void setEscuderia(String escuderia) {
        this.escuderia = escuderia;
    }
    
    //metodos
    @Override
    public String toString() {
        return super.toString() + " escuderia=" + escuderia;
    }
    
    //aplico polimorfismo al metodo acelerar del padre(Auto)
    @Override
    public void acelerar() {
        this.velocidad += 50;
    }
    
}
