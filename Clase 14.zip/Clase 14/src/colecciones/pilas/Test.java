package colecciones.pilas;

import java.util.Stack;

public class Test {
    public static void main(String[] args) {
       //creo una coleccion de tipo pila(LIFO) -> stack
        Stack pila = new Stack();
        
        //agrego objetos en la pila
        pila.push("Juan");
        pila.push("Maria");
        pila.push("Luis");
        pila.push("Carlos");
        
        System.out.println(pila);
        
        System.out.println("Contenido original de la pila: " + pila);
        
        System.out.println("Tamaño de la pila: " + pila.size());
        
        System.out.println("1er objeto a salir de la pila: " + pila.peek());
        
        System.out.println("sacamos un objeto de la pila: " + pila.pop());
        
        System.out.println("nuevo contenido de la pila: " + pila);//salio Carlos
       
        System.out.println("Pila vacia?: " + pila.empty());
        
        
        
        
        
        
       
       
    }
}
