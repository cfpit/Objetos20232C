package colecciones.listas;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        //creo la coleccion de tipo lista
//        List lista = new ArrayList();//coleccion no tipada
//        List<Persona> lista = new ArrayList<Persona>();//coleccion tipada
//        List<Persona> lista = new ArrayList<>();//coleccion tipada
        ArrayList<Persona> lista = new ArrayList<>();//coleccion tipada
        
        //creo objetos de la clase Persona
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Maria", 30);
        Persona p3 = new Persona("Luis", 20);
        Persona p4 = new Persona("Carlos", 40);
        
        //agrego los objetos en la coleccion
        lista.add(p1);
        lista.add(p2);
        lista.add(p3);
        lista.add(p4);
        
        System.out.println("Contenido de la lista: " + lista);
        
        System.out.println("-------------------------------");
        
        System.out.println("Recorro la coleccion con for");
        // forl
        for (int i = 0; i < lista.size(); i++) {
            Persona get = lista.get(i);
            System.out.println(get);
        }
        
        System.out.println("-------------------------------");
        
        System.out.println("Recorro la coleccion con foreach");
        // fore
        for (Persona unaPersona : lista) 
        {
            if (unaPersona.getEdad() > 28)
            {
                System.out.println(unaPersona);
            }
        }
        
        System.out.println("-------------------------------");
        
        System.out.println("Recorro la coleccion con patron iterator");
        // whileit
        
        Iterator it = lista.iterator();
        while (it.hasNext()) 
        {
            Object next = it.next();
            System.out.println(next);
        }
        
        //elimino el 1er objeto de la lista
        lista.remove(0);
        
        //nuevo contenido
        System.out.println(lista);
        
        //agrego un objeto en la 3ra posicion de la lista
        Persona p5 = new Persona("Pedro", 45);
        lista.add(2, p5);
        
        System.out.println(lista);
        
    }
}







