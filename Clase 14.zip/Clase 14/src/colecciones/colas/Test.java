package colecciones.colas;

import java.util.LinkedList;
import java.util.Queue;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo cola(FIFO) -> queue
        Queue cola = new LinkedList();
        
        //agrego elementos en la cola
        cola.add("Juan");
        cola.add("Maria");
        cola.add("Luis");
        cola.add("Carlos");
        
        System.out.println("Tamaño de la cola: " + cola.size());
        
        System.out.println("1er objeto a salir de la cola: " + cola.peek());
        
        System.out.println("sacamos un objeto de la cola: " + cola.poll());
        
        System.out.println("contenido de la cola: " + cola);//salio Juan

    
    }
}
