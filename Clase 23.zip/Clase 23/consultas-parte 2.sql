-- funciones de agrupacion
use pubs;

-- listar la fecha de ingreso del 1er empleado
select min(hire_date)  as 'fecha de ingreso' from employee;-- 1988-10-09

-- listar la fecha de publicacion del ultimo libro
select max(pubdate) 'fecha ultimo libro' from titles;-- 1998-06-01 

-- Informar la cantidad de horas trabajadas en promedio por todos los empleados
select avg(job_lvl) 'horas promedio' from employee;-- 86.3721 horas

-- Informar la cantidad de autores de California
select count(au_id) 'autores de California' from authors where state = 'ca';-- 15

-- Informar la sumatoria de precios de todos los libros
select sum(price) as total from titles;-- 236.26 U$s

-- Todas las funciones de agrupacion en una sola query
select	max(price) 'libro mas caro',
		min(price) 'libro mas barato',
		count(price) cantidad,
		round(avg(price),2) promedio,
		round(sum(price),2) total
from	titles;

-- Agrupaciones
-- Listar las cantidad de titulos por categoria. No incluir las categorias de cocina.
-- Considerar solo las categorias cuya cantidad de libros sea mayor que 2.
-- Ordenar por cantidad en forma descendente.
select		type categoria,
			count(title_id) as cantidad
from		titles
where		type not like '%cook%'-- where filtra condicionando campos
group by	type
having		count(title_id) > 2 -- having filtra condicionando funciones de agrupacion
order by	2 desc; 

-- Consultas relacionadas
-- INNER JOIN
-- Listar nombre y apellido de los autores que escribieron libros de psicologia.
-- Informar el nombre de las editoriales que lo publicaron.
select		concat(a.au_fname,' ',a.au_lname) as autor,
			t.type as categoria,
			p.pub_name as editorial
from		authors a
inner join	titleauthor ta on a.au_id = ta.au_id
inner join	titles t on t.title_id = ta.title_id
inner join	publishers p on t.pub_id = p.pub_id
where		t.type like '%psy%';
-- OUTER JOIN (left o right)
-- Listar el nombre de los libros de cocina que no se vendieron
-- tabla ppal: titles / tabla secundaria: sales
select		t.title libro
			-- , s.*
from		sales s right join titles t
on			s.title_id = t.title_id
where		s.stor_id is null and t.type like '%cook%';
-- where		s.stor_id is null;


/*
	SQL
		--> DDL: lenguaje de definicion de datos
			--> CREATE 
            --> ALTER
            --> DROP
            --> operan sobre objetos: bases, tablas, vistas, etc.
		--> DML: lenguaje de manipulacion de datos
			--> SELECT 
            --> INSERT
            --> UPDATE
            --> DELETE
            --> operan sobre registros

*/

create database colegio;

use colegio;

create table alumnos(
	nombre varchar(20),
    edad int
);

insert into alumnos values
('Juan',25),('Maria',20),('Carlos',45),('Ana',30);

select * from alumnos;

update alumnos set edad = edad + 1 where nombre = 'Juan';
select * from alumnos;

delete from alumnos where nombre = 'Ana';
select * from alumnos;

alter table alumnos add column mail varchar(50);
describe alumnos;

drop table alumnos;





































