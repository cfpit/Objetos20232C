package base;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
    
    public static Connection obtenerConexion() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        //establecemos el driver de conexion
        String driver = "com.mysql.cj.jdbc.Driver";
        
        //establecemos la cadena de conexion
        String conexion = "jdbc:mysql://127.0.0.1:3306/colegio";
        
        //credenciales
        String usuario = "root";
        String clave = "";
        
        //Creo un objeto de la clase Driver por API Reflection
        Class.forName(driver).newInstance();
        
        //retorno el objeto de tipo Connection que contiene
        //la info de el servidor, la base y las credenciales de conexion
        return DriverManager.getConnection(conexion, usuario, clave);
    }
}
