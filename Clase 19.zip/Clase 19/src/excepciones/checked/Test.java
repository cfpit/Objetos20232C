package excepciones.checked;

public class Test {
    public static void main(String[] args) throws NoHayMasPasajesException {
        Vuelo v = null;
        
        try {
            //creo un vuelo
            v = new Vuelo("ABC-123", 100);

            //vendemos pasajes
            v.venderPasajes(25);
            v.venderPasajes(30);
            v.venderPasajes(10);
            v.venderPasajes(2);
            v.venderPasajes(40);//esta linea lanza la excepcion
            
            
        } catch (NoHayMasPasajesException e) {
            e.mensajeError();
        }
        
        System.out.println(v);
    }
}
