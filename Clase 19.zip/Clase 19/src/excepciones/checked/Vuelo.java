package excepciones.checked;

public class Vuelo {
    private String nombre;
    private int capacidad;

    public Vuelo() {}

    public Vuelo(String nombre, int capacidad) {
        this.setNombre(nombre);
        this.setCapacidad(capacidad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    @Override
    public String toString() {
        return "Vuelo{" + "nombre=" + nombre + ", capacidad=" + capacidad + '}';
    }
    
    public void venderPasajes(int pedidos) throws NoHayMasPasajesException {
        //si me pidieron mas asientos q capacidad restente tiene el vuelo...
        if (pedidos > this.capacidad) 
        {
            //...entonces, lanzo manualmente la excepcion de usuario
            throw new NoHayMasPasajesException(this.nombre, pedidos);
        } 
        else 
        {
            this.capacidad -= pedidos;
        }
    }
}
